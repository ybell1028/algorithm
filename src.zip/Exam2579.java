import java.io.*;

public class Exam2579 {
    public static int[] stairs;
    public static int[][] dp;
    public static int N, MAX;

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

        N = Integer.parseInt(br.readLine());
        MAX = Integer.MIN_VALUE;

        stairs = new int[N + 1];
        dp = new int[N + 1][3];

        for(int i = 1; i <= N; i++){
            stairs[i] = Integer.parseInt(br.readLine());
        }



        for(int i = 1; i <= N; i++){
            dp[i][0] = dp[i-1][0] + stairs[i-1];
            dp[i][1] = dp[i-1][1] + stairs[i];
        }

        bw.write(String.valueOf(MAX + "\n"));

        bw.flush();

        br.close();
        bw.close();
    }

    public static void onetwo(int start){ // 둘 중 큰거 리턴
        return max(stairs[start + 1] + stairs[start + 3])
    }
    public static void twoone(int start){

    }
    public static void twotwo(int start){}9

    public static int max(int a, int b) { return a > b ? a : b; }
}
