import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class fuck {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String destination = br.readLine();

        int milk = 0;
        boolean abocado = false;

        if(destination.equals("mart")){
            boolean exist_abocado = Boolean.parseBoolean(br.readLine());
            if(exist_abocado) abocado = true;
            if(abocado) {
                System.out.println("아보카도 있었어");
                milk = 6;
            }
            else {
                System.out.println("아보카도 없었어");
                milk = 1;
            }
        }

        System.out.println("우유의 갯수 : " + milk);
    }
}
